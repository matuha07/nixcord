{ ... }:
{
  virtualisation.docker = {
    enable = true;
  };
}
